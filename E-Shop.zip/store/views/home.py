from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from store.models.product import Product
from store.models.Category import Category
from store.models.customer import Customer
from django.views import View

class Index(View):
    #for add to cart request
    def post(self,request):
        product=request.POST.get('product')
        remove=request.POST.get('remove')
        cart=request.session.get('cart')
        if cart:
            quantity=cart.get(product)
            if quantity :
                if remove:
                    if quantity==1:
                        cart.pop(product)
                    else:
                        cart[product]=quantity-1
                else:
                    cart[product]=quantity+1
            else:
            # {product_id,quantity}
                cart[product]=1 
        else:
            # if cart was not there already i need to create one
            cart={}
            cart[product]=1;
        request.session['cart']=cart;
        # print(request.session['cart'])
        return redirect('homepage')


    def get(self,request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart']={}
        products=None
        #request.session.clear()
        categories=Category.get_all_categories();
        # category_id=request.GET['category']  => if i use this and don't get any category id it will throw error
        category_id=request.GET.get('category')
        if category_id:
            products=Product.get_all_products_by_category_id(category_id);
        else:
            products=Product.get_all_products();

        data={}
        data['products']=products
        data['categories']=categories
        print('you are :', request.session.get('email'))
        return render(request,'Index.html',data)



    






        

    




