from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from store.models.product import Product
from store.models.Category import Category
from store.models.customer import Customer
from django.views import View






# def validateCustomer(customer):
#         msg=None
#         if(not customer.first_name):
#             msg="First Name Required"
#         elif len(customer.first_name)<4:
#             msg="First Name must be atleast 4 character long"
#         elif(not customer.last_name):
#             msg="Last Name Required"
#         elif len(customer.last_name)<4:
#             msg="Last Name must be atleast 4 character long"
#         elif(not customer.phone):
#             msg="Phone Number Required"
#         elif len(customer.phone)<10:
#             msg="Phone Number must have 10 digits"
#         elif(not customer.email):
#             msg="Email id Required"
#         elif len(customer.email)<4:
#             msg="email must be atleast 4 character long"
#         elif(not customer.password):
#             msg="password Required"
#         elif len(customer.email)<6:
#             msg="password must be atleast 6 character long"
#         elif customer.isExists():
#             msg="Email Address already Registered"
#         return msg



# def registerUser(request):
#     postData=request.POST
#         first_name=postData.get('firstname')
#         last_name=postData.get('lastname')
#         phone=postData.get('phone')
#         email=postData.get('email')
#         password=postData.get('password')
#         customer=Customer(first_name=first_name,last_name=last_name,phone=phone,email=email,password=password)
#         value={'first_name':first_name,'last_name':last_name,'phone':phone,'email':email}
#         #validation :
#         msg=validateCustomer(customer)
#         #saving :
#         if not msg :
#             customer.password=make_password(customer.password)
#             customer.register()
#             return redirect('homepage')
#         else:
#             data={'error':msg,'values':value}   #data is object passed
#             return render(request,'signup.html',data) # request.POST gives a dictionary value can accessed as request.POST.get(email) 
#         # key of dictionary will be 'name' used in form 
        





# class based view used for login and signup  

class Login(View):

    #for get request
    # self because it is instance of same class
    def get(self,request):
        return render(request,'login.html')

    #for post request
    def post(self,request):
        email=request.POST.get('email')
        password=request.POST.get('password')
        customer=Customer.get_customer_by_email(email)
        msg=None
        if customer :
           # print(password,email)
            flag=check_password(password,customer.password)
            if flag:
                request.session['customer']=customer.id
                #request.session['email']=customer.email
                
                return redirect('homepage')
            else:
                msg="Email or Password invalid!!"
        else:
            msg="Email or Password invalid!!"

        return render(request,'login.html',{'error':msg})
def logout(request):
    request.session.clear()
    return redirect('login')



    






        

    




