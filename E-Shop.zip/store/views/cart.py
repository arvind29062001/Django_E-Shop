from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from store.models.product import Product
from store.models.Category import Category
from store.models.customer import Customer
from django.views import View






# class based view used for login and signup  

class Cart(View):

    #for get request
    # self because it is instance of same class
    def get(self,request):
        ids=(list(request.session.get('cart').keys()))
        products=Product.get_products_by_id(ids)
        
        return render(request,'cart.html',{'products':products})

    



    






        

    




